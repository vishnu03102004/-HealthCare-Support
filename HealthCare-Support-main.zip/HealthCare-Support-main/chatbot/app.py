import os
from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
import requests
from dotenv import load_dotenv
import re

load_dotenv()

app = Flask(__name__)
CORS(app)

GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
GEMINI_URL = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent?key={GEMINI_API_KEY}"

def clean_gemini_reply(reply):
    reply = reply.strip()
    reply = re.sub(r'\*+', '', reply)  # Remove all asterisks
    reply = re.sub(r'`+', '', reply)    # Remove backticks
    reply = re.sub(r'_+', '', reply)    # Remove underscores
    reply = re.sub(r'#+ ', '', reply)   # Remove markdown headers
    reply = re.sub(r'> ', '', reply)    # Remove blockquote markdown
    reply = re.sub(r'\n{3,}', '\n\n', reply)  # Collapse multiple newlines
    return reply

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    user_message = request.json.get("message")
    payload = {
        "contents": [
            {
                "parts": [{"text": user_message}]
            }
        ]
    }
    headers = {"Content-Type": "application/json"}
    try:
        r = requests.post(GEMINI_URL, headers=headers, json=payload)
        r.raise_for_status()
        data = r.json()
        reply = data["candidates"][0]["content"]["parts"][0]["text"]
        reply = clean_gemini_reply(reply)
        return jsonify({"reply": reply})
    except Exception as e:
        return jsonify({"reply": f"Error: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(debug=True) 