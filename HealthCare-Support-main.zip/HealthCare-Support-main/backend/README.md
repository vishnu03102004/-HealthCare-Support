# Healthcare Backend Authentication

This backend provides user registration and login with MongoDB for the Health Care Support for Rural Areas project.

## Features
- User registration (username & password)
- User login (JWT authentication)
- Passwords hashed with bcrypt

## Setup

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start MongoDB locally (or update the connection string in `server.js` for Atlas).
3. Start the server:
   ```bash
   npm start
   ```
4. The API will run on `http://localhost:5000`

## API Endpoints

- `POST /api/register` — Register a new user
  - Body: `{ "username": "yourname", "password": "yourpass" }`
- `POST /api/login` — Login and receive a JWT
  - Body: `{ "username": "yourname", "password": "yourpass" }`

## Notes
- Change `JWT_SECRET` in `server.js` for production use.
- Use HTTPS in production. 