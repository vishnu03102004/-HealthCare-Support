import os
import base64
from flask import Flask, request, jsonify
from flask_cors import CORS
import requests
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()

GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')
# Hardcoded endpoint for gemini-1.5-flash-latest
GEMINI_API_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash-latest:generateContent'

app = Flask(__name__)
CORS(app)  # Allow all origins by default

@app.route('/api/gemini-chat', methods=['POST'])
def gemini_chat():
    user_message = request.form.get('message', '')
    image_file = request.files.get('image')

    if not user_message and not image_file:
        return jsonify({'reply': 'No message or image provided.'}), 400

    # Construct the parts of the request for Gemini
    parts = []
    if user_message:
        parts.append({'text': user_message})

    if image_file:
        # Check for valid image
        if not image_file.content_type.startswith('image/'):
             return jsonify({'reply': 'Invalid file type. Please upload an image.'}), 400
        
        img_bytes = image_file.read()
        img_base64 = base64.b64encode(img_bytes).decode('utf-8')
        parts.append({
            'inline_data': {
                'mime_type': image_file.content_type,
                'data': img_base64
            }
        })

    body = {
        'contents': [{'parts': parts}]
    }

    headers = {
        'Authorization': f'Bearer {GEMINI_API_KEY}',
        'Content-Type': 'application/json'
    }
    
    try:
        response = requests.post(GEMINI_API_ENDPOINT, json=body, headers=headers, timeout=30)
        response.raise_for_status()
        data = response.json()
        
        # Handle cases where the API returns no candidates or content
        if not data.get('candidates'):
            # Check for safety ratings if content is blocked
            prompt_feedback = data.get('promptFeedback', {})
            block_reason = prompt_feedback.get('blockReason', 'unknown reason')
            return jsonify({'reply': f'Request blocked due to: {block_reason}. Please adjust your prompt.'}), 400

        reply = data['candidates'][0].get('content', {}).get('parts', [{}])[0].get('text', 'Could not process the response.')
        return jsonify({'reply': reply})

    except requests.exceptions.HTTPError as http_err:
        return jsonify({'reply': f'HTTP error occurred: {http_err}. Check your API Key and endpoint.'}), 500
    except requests.exceptions.RequestException as e:
        return jsonify({'reply': f'Network error with the AI service: {e}'}), 500
    except Exception as e:
        return jsonify({'reply': f'An unexpected error occurred: {e}'}), 500

if __name__ == '__main__':
    # Running on port 5001 to avoid conflict with Node.js server on 5000
    port = int(os.environ.get('PORT', 5001))
    app.run(host='0.0.0.0', port=port, debug=True) 